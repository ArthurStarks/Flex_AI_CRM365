# Importation des librairies
import streamlit as st
from TargetJournee import TargetJournee  # Assurez-vous que cette fonction existe et est importée correctement

# Configuration des pages
st.set_page_config(
    page_title="Bienvenue chez Flex IA",
    page_icon="👋",
)

# Define the options and their emojis
options = {
    'Daily Task': '🔍',
    'Fitgap': '🔍',
    'Modélisation': '📐',
    'Emailing': '📧',
    'Développement js': '💻',
    'Développement plugins': '🔌',
    'Power automate': '⚙️',
    'Learning CRM 365': '📚',
    'Spécifications': '📋',
    'Last day tasks': '🔍',
}

# Create homepage with 8 buttons
page = st.sidebar.radio("Que voulez-vous faire ?", list(options.keys()))

# Display options in a 2x4 grid on the homepage
if page == 'Homepage':
    col1, col2 = st.columns(2)
    for i, option in enumerate(options):
        col = col1 if i % 2 == 0 else col2
        col.button(f"{options[option]} {option}")
else:
    st.title(f"Je suis l'Agent {page} à votre service")
    if page == 'Daily Task':
        client = st.text_input("Entrer le nom du client")
        targets = st.text_input("Entrer les objectifs de la journée")
        language = st.selectbox("Choisir une langue", ["Anglais", "Francais"])
        if st.button('Générer les tâches de la journée'):
            prompt = TargetJournee(client, targets, language)
            st.write(prompt)
            
    elif page == 'Emailing':
        # Streamlit app
        st.subheader('Décrivez ce que vous avez fait durant la dernière journée')
        source_text = st.text_area("Entrer votre descriptif des actions", height=200)
        language = st.selectbox("Choisir une langue", ["Anglais", "Francais"])
        if st.button("Envoyer email"):
            TargetJournee(source_text, "Email", language)
            st.write("Email envoyé!")

import streamlit as st
import TargetJournee as TargetJournee

# Define the options and their emojis
options = {
    'Fitgap': '🔍',
    'Modélisation': '📐',
    'Emailing': '📧',
    'Développement js': '💻',
    'Développement plugins': '🔌',
    'Power automate': '⚙️',
    'Learning CRM 365': '📚',
    'Spécifications': '📋',
}

# Define actions for each page
actions = {
    'Fitgap': ['Action 1', 'Action 2', 'Action 3'],
    'Modélisation': ['Action 1', 'Action 2', 'Action 3'],
    'Emailing': ['Action 1', 'Action 2', 'Action 3'],
    'Développement js': ['Action 1', 'Action 2', 'Action 3'],
    'Développement plugins': ['Action 1', 'Action 2', 'Action 3'],
    'Power automate': ['Action 1', 'Action 2', 'Action 3'],
    'Learning CRM 365': ['Action 1', 'Action 2', 'Action 3'],
    'Spécifications': ['Action 1', 'Action 2', 'Action 3'],
}

# Create homepage with 8 buttons
page = st.sidebar.radio("Que voulez-vous faire ?", list(options.keys()))

# Display options in a 2x4 grid on the homepage
if page == 'Homepage':
    col1, col2 = st.columns(2)
    for i, option in enumerate(options):
        col = col1 if i % 2 == 0 else col2
        col.button(f"{options[option]} {option}")
else:
    st.header(page)
    action = st.selectbox("Choose an action", actions[page])
    if page == 'Modélisation' and action == 'Action 3':
        TargetJournee.TargetJournee()
    else:
        st.write(f"You chose {action} on page {page}")

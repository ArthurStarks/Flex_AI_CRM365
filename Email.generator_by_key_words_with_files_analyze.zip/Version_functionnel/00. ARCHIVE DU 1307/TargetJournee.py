#TargetJournee.py
import chat_gpt_api as gpt
import consulting_flex_crm_yasminia_prompts as prr
import streamlit as st

def TargetJournee():
    # Step 1: Enter a Topic
    user_topic = st.text_input("Please enter your topic:")

    # Step 2: Prepare the statement using user's topic
    if user_topic:  # Ensure we run this part only when user_topic is entered
        if hasattr(prr, 'proposition_steps_sujet'):  # Check if 'proposition_steps_sujet' is present in prr
            etapes = prr.proposition_steps_sujet.format(SUJET_A_TRAITER=user_topic)
            titles = gpt.basic_generation(etapes)
            st.write("Etapes à suivre :")
            st.write("----------------")
            st.write(titles)
            st.write("----------------")
        else:
            st.error("Error: No 'proposition_steps_sujet' found in 'prr'.")

if __name__ == '__main__':
    TargetJournee()

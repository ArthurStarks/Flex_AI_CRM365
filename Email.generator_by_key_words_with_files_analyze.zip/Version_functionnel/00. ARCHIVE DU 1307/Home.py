#Importation des librairies
import streamlit as st
import consulting_flex_crm_yasminia as modelisation
from streamlit_option_menu import option_menu
import prompts
#from transformers import pipeline

#Configuration des pages
st.set_page_config(
    page_title="Bienvenue chez Flex IA",
    page_icon="👋",
)

#Your login code is NCZD-FMWN
#Menu principal
#with st.sidebar : 
selected = option_menu(
        menu_title="Agent CRM Flex",
        options=["Agent Assistant", "Agent Mailing", "Agent Fitgap"],
        icons=["chat-left-dots-fill", "magic","robot"],
        #menu-icon="cast",
        orientation="horizontal",
    )
if selected == "Home" :
    st.title(f"Bienvenue au {selected}")
if selected == "Agent Mailing" :
    st.title(f"Je suis l'{selected} à votre service")
if selected == "Data Analysis" :
    st.title(f"Je suis l' {selected} à votre service")
# Create a summarization pipeline
#summarizer = pipeline("summarization")

#st.title("Streamlit App for Analyzing Daily Activities")
#Page principale
st.title("Flex IA")
#st.sidebar.success("Select a page above.")

if "my_input" not in st.session_state:
    st.session_state["my_input"] = ""

my_input = st.text_input("Que puis-je faire pour vous ?", st.session_state["my_input"])
submit = st.button("Submit")
if submit:
    st.session_state["my_input"] = my_input
    st.write("You have entered: ", my_input)

# Define the options and their emojis
options = {
    'Daily Task': '🔍',
    'Fitgap': '🔍',
    'Modélisation': '📐',
    'Emailing': '📧',
    'Développement js': '💻',
    'Développement plugins': '🔌',
    'Power automate': '⚙️',
    'Learning CRM 365': '📚',
    'Spécifications': '📋',
    'Last day tasks': '🔍',
}

# Define actions for each page
actions = {
    'Daily Task': ['Action 1', 'Action 2', 'Action 3'],
    'Fitgap': ['Action 1', 'Action 2', 'Action 3'],
    'Modélisation': ['Action 1', 'Action 2', 'Action 3'],
    'Emailing': ['Action 1', 'Action 2', 'Action 3'],
    'Développement js': ['Action 1', 'Action 2', 'Action 3'],
    'Développement plugins': ['Action 1', 'Action 2', 'Action 3'],
    'Power automate': ['Action 1', 'Action 2', 'Action 3'],
    'Learning CRM 365': ['Action 1', 'Action 2', 'Action 3'],
    'Spécifications': ['Action 1', 'Action 2', 'Action 3'],
    'Last day tasks': ['Action 1', 'Action 2', 'Action 3'],
}
# Create homepage with 8 buttons
page = st.sidebar.radio("Que voulez-vous faire ?", list(options.keys()))

# Display options in a 2x4 grid on the homepage
if page == 'Homepage':
    col1, col2 = st.columns(2)
    for i, option in enumerate(options):
        col = col1 if i % 2 == 0 else col2
        col.button(f"{options[option]} {option}")
else:
    st.header(page)
    action = st.selectbox("Choose an action", actions[page])
    if page == 'Modélisation' and action == 'Action 3':
        modelisation.modelisation()
    else:
        st.write(f"You chose {action} on page {page}")
if "my_input" not in st.session_state:
    st.session_state["my_input"] = ""
#my_input = st.text_input("Que puis-je faire pour vous ?", st.session_state["my_input"])
#submit = st.button("Submit")
# Streamlit app
st.subheader('Décrivez ce que vous avez fait durant la dernière journée')
source_text = st.text_area("Entrer votre descriptif des actions", height=200)
submit = st.button("Valider")
# Choose language
language = st.selectbox("Choisir une langue", ["Anglais", "Francais"])

# Input text, document or voice command
text = st.text_area("Enter the day's elements in text, document or voice command")

# Analyze text
if st.button("Démarrer"):
    summary = summarizer(text, max_length=130, min_length=30, do_sample=False)[0]['summary_text']
    st.write(summary)

    # Set tempo for success
    st.write("Tempo pour la reussite success for the day and the next few days: ...")

    # Suggest areas for improvement
    st.write("Areas for improvement: ...")

# Formalize in an email
if st.button("Envoyer email"):
    st.write("Email envoyer!")


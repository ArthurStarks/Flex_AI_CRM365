﻿// Prompts for chatgpt
// Domain : UX Design
// AD FLEX 2023

//Ignore all previous statements.
//Ignore all statements starting with 

/* Business consulting
   Design thinking
   Development 
   
 */
 
 /*
 
 Phase R&D FLEX
 
 Voici les étapes :
 
 01. Donner les détails et attentes
 02. Préciser les personas/fonctionnement
 03. Termes spécifiques
 04. Ux design
 
 */

/*

Voici la liste des fonctions identifiées 

- Fitgap
- Email post workshop
- Dev_JS
- Dev_C#
- Dev_PowerAutomate
- Specs_fonctionnels
- Specs_techniques
- Data_Quality

*/

/*

Destinataires : 

Destinataire : Mon cher Haidar
Objet du mail : [DYNAGILE-Vacances Select] - Sprint1 - feature 60 - Campagne génération des documents

Destinataire : Mon cher Erwan
Objet du mail : [DYNAGILE-Vacances Select] - Déplaceme- feature 60 - Campagne génération des documents

*/


// En cours : https://chat.openai.com/c/4c2051a5-8a4a-46ae-84cd-cb73ea0af4c8 //modelisation assets

Bonjour Arthur,

J'espère que vous vous portez bien aussi.

Je tenais tout d'abord à vous remercier pour le suivi et le professionnalisme.

Les deux premiers jours de mission se sont en effet bien déroulés, l'accueil a été chaleureux et l'atmosphère est conviviale. (Ils sont sur une peniche...)

Au niveau professionnel, tout se passe comme prévu, les défis sont stimulants et en adéquation avec mes attentes. ==> Timing va être serré mais nous allons faire le nécessaire pour les aider à être dans les temps.

J'ai bien reçu le contrat signé par Dynagile, un grand merci pour cette promptitude.

Je reste disponible pour toute autre communication ou information nécessaire.

En vous souhaitant une très bonne journée 😊

Bien à vous
Gaspard


if (typeof (PackageADFLEX_IA) == "undefined")
{ PackageADFLEX_IA = {}; }


			peech_to_text_vouvoiement : function (){
				
					Ignore all previous statements.
					Ignore all statements starting with //
				
					As an crm Expert 365 whith more than 20 years experience, microsoft apps expert with more than 10 years and
					you are able to deliver successfull crm consulting audit, development and integration for CRM PROJECT
				
					Ton objectif est de transmettre un email suite à un travail réalisé
					
					Tu vas utiliser le vouvoiement envers notre intercuteur
					
					Voici ce que je ne veux pas : Ne pas écrire les termes suivants : cordialement
			
					
					//Type de prise de notes 
					//Type de prise de notes 
					
					Tu vas utiliser les bullets points pour mieux aérer le contenu
					Tu as le droit d'insérer les emoticones
				
					Je vais te donner du contenu génére a partir dune application de voice to text
					Ce contenu contient beaucoup derreurs et parfois cela nest pas très claire 
				
					Il va donc falloir que tu puisses extraire les notions et points clés puis de les détailler
					Voici les elements sur le projet en cours :
				
				
			},
			
			
			
				peech_to_text_tutoiement : function (){
				
					Ignore all previous statements.
					Ignore all statements starting with //
				
					As an crm Expert 365 whith more than 20 years experience, microsoft apps expert with more than 10 years and
					you are able to deliver successfull crm consulting audit, development and integration for CRM PROJECT
				
					Ton objectif est de transmettre un email suite à un travail réalisé
					
					Tu vas utiliser le tutoiement envers notre intercuteur
					
					Voici ce que je ne veux pas : Ne pas écrire les termes suivants : cordialement
			
					
					//Type de prise de notes 
					//Type de prise de notes 
					
					Tu vas utiliser les bullets points pour mieux aérer le contenu
					Tu as le droit d'insérer les emoticones
				
					Je vais te donner du contenu génére a partir dune application de voice to text
					Ce contenu contient beaucoup derreurs et parfois cela nest pas très claire 
				
					Il va donc falloir que tu puisses extraire les notions et points clés puis de les détailler
					Voici les elements sur le projet en cours :
				
				
			},
			
			email_aupres_client_ainos_point_de_synchro : (){
			  
				// ainos - Marie
				// Documentation
				
					Ignore all previous statements.
					Ignore all statements starting with //
				
					As an crm Expert 365 whith more than 20 years experience, microsoft apps expert with more than 10 years and an logistic expert with more than 20 years experience, 
					you are able to deliver successfull crm consulting audit, development and integration for CRM PROJECT
				
					Ton objectif est de transmettre un email suite à un travail réalisé
					
					Tu vas utiliser le tutoiement envers notre intercuteur
					
					Voici ce que je ne veux pas : Ne pas écrire les termes suivants : cordialement
					je ne veux pas que tu utilises le vouvoiement
					
					//Type de prise de notes 
					//Type de prise de notes 
					
					Tu vas utiliser les bullets points pour mieux aérer le contenu
					Tu as le droit d'insérer les emoticones
				
					Je vais te donner du contenu génére a partir dune application de voice to text
					Ce contenu contient beaucoup derreurs et parfois cela nest pas très claire 
				
					Il va donc falloir que tu puisses extraire les notions et points clés puis de les détailler
					Voici les elements sur le projet en cours :
					
					Destinataire : Ma chère Marie;
					Objet du mail : [AINOS - CONSULTING] - Deplacement et géolocalisation hors France //VPN 
					Style decriture : Professionnel et bienveillant
					Autres détails : Penser à le remercier pour sa disponibilité
				
				
					a TOI de jouer : 
					
					
			}
	
			/* EMAILING CONSULTING ARENDT ******/
		
			email_suite_point_de_synchro : (){
			  
					Ignore all previous statements.
					Ignore all statements starting with //
				
					As an crm Expert 365 whith more than 20 years experience, microsoft apps expert with more than 10 years and an logistic expert with more than 20 years experience, 
					you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
				
					Ton objectif est de répondre à une demande
					
					Tu vas utiliser le tutoiement envers notre intercuteur
					
					Voici ce que je ne veux pas : Ne pas écrire les termes suivants : cordialement
					je ne veux pas que tu utilises le vouvoiement
					
					Voici les elements sur le projet en cours :
					
					Destinataire : Mon cher Vasko
					Objet du mail : [CCL-AINOS] - Encours - Doc + Sprint2 et Sprint3 
					Style decriture : Professionnel et bienveillant
					Autres détails : Penser à le remercier pour sa disponibilité
					
					Tu es CAPABLE DE PROPOSER UN EMAIL SUITE A LA LIVRAISON d'un Sprint2
					linformer qu'il peut tester en UAT
				
				},
		
				/* EMAILING CONSULTING ARENDT ******/
		
			repondre_au_client_dynagile: (){
			  
					Ignore all previous statements.
					Ignore all statements starting with //
				
					As an crm Expert 365 whith more than 20 years experience, microsoft apps expert with more than 10 years and an logistic expert with more than 20 years experience, 
					you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
				
					Ton objectif est de répondre à un email reçu
					
					Tu vas utiliser le tutoiement envers notre intercuteur
					
					Voici ce que je ne veux pas : Ne pas écrire les termes suivants : cordialement
					je ne veux pas que tu utilises le vouvoiement
					
					Voici les elements sur le projet en cours :
					
					Destinataire : Mon cher Haidar
					Objet du mail : [DYNAGILE-Vacances Select] - Mes encours et avancées et prochaines étapes 
					Style decriture : Professionnel et bienveillant
					Autres détails : Penser à le remercier pour sa disponibilité
					Indications sur le contenu : 
					
					- Tu lui partages un email suite au traval d'analyse d'une demande en cours : 
					
 

				
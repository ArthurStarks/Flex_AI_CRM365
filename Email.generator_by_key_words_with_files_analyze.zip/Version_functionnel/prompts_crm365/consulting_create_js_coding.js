﻿// Prompts for chatgpt
// Domain : UX Design
// AD FLEX 2023

//Ignore all previous statements.
//Ignore all statements starting with 

/* Business consulting
   Design thinking
   Development 
   
 */
 
 /*
 
 Phase R&D FLEX
 
 Voici les étapes :
 
 01. Donner les détails et attentes
 02. Préciser les personas/fonctionnement
 03. Termes spécifiques
 04. Ux design
 
 */

/*

Voici la liste des fonctions identifiées 

- Fitgap
- Email post workshop
- Dev_JS
- Dev_C#
- Dev_PowerAutomate
- Specs_fonctionnels
- Specs_techniques
- Data_Quality

*/


// En cours : https://chat.openai.com/c/4c2051a5-8a4a-46ae-84cd-cb73ea0af4c8 //modelisation assets

// ainos_movementtype
// ainos_ajustmenttype

Purchase (Entrée)  192,400,000
Event return (Entrée) 192,400,001
Event release (Sortie) 192,400,002
One-off consumption (Sortie) 192,400,003
Stock Adjustment (In et out) 192,400,004



if (typeof (PackageADFLEX_IA) == "undefined")
{ PackageADFLEX_IA = {}; }

PackageADFLEX_IA.ADFLEX_IA = {
	
	
	
	 update_the_code_based_on_requirement : () {
			
			Ignore all previous statements.
			Ignore all statements starting with //
			
			As an crm Expert 365 whith more than 20 years experience, microsoft apps expert with more than 10 years and an logistic expert with more than 20 years experience, 
			you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
			
			I need you to think about this project, manage personas, understand the requirements and deliver the solution for crm desktop and mobile applicaiton

			
			If it make sense, you will suggest a best link for similar project where i can find : Solutions, files, prototypes, uses cases etc...
			Your job is to deliver : audit, specifications fonctionnelles générales, spécifications techniques, backlog for the business rules,
			crm customizations that includes entity, forms, views, fields,reporting, dashboard, creating js code, plugins, workflows, power automate, 
			power apps and suggest testing
			
			I WANT you create a js code based on this requirement 
			
			use this code below to update and fit the new requirement
			
			NOW I WILL give you the code to update :
			function onMovementtypeChanged (executionContext) {
    
    var movementType = formContext.getAttribute("ainos_movementtype").getValue();

    if (movementType != null && movementType == 192400000) { // Purchase
        Display field "ainos_supplier"
        Set it mandatory
    } else {  Hide field "ainos_supplier"
        Set it mandatory
}

}
		
		},
		
			dev_js_generate_js_file_for_new_requirement : function (){
				// Generate new JS file based on new requirement
		
					Ignore all previous statements.
					Ignore all statements starting with //
					
					As an crm Expert 365 whith more than 20 years experience and
					and dev expert in c#, js and power automate/apps and
					microsoft apps expert with more than 10 years and 
					an logistic expert with more than 20 years experience, 
					
					// La mission qu'il a en général par rapport au contexte
					you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
					
					I need you to deliver solution going step by step :
					
					I need you to think about this requirement and create a js file that fit the requirement
					
					Before answering, i will share with you some sample of other js code that work perfectly for the current project
					
					Once you read them and understand, i need you to generate functions that work for the current requirement
					and then you will update to make it worked
							
					Before answering, ask me any question if it's not clear 
					
					We will work into 3 steps :
					
					01. Step1 = Ask me existing file
					02. Step2 = Ask me the requirement
					03. Step3 = deliver the updated code that fit the requirement
					
					Please memorize the names of step, so i can ask you restart just by giving you the name of step;
			
					Please ask me if the step is complete before going to the next step.
				
					Use French language 
					Let's go 
		
				},
				
				 all_step1__projet : function (details_attentes_du_projet, nbre_des_parties){
		
				  //Ignore all previous statements.
				  
					Ta comprehension est bonne 
					Bravo, merci detre force de proposition
					
					Ignore all statements starting with //
					Tu es à letape 1
					01. Step1 = Ask me existing file
					
					
					As an crm Expert 365 whith more than 20 years experience, microsoft apps expert with more than 10 years and an logistic expert with more than 20 years experience, 
					you are able to design perfect app solution for inventory management de manière optimisée. 
					
					As i will give you a long format of file, i will give you in many times, so ask if i sent you the entire file before going to the next step (step2)
					
					Use French language 
					Here is the first part of existing file : 
					// Ici faut prendre 2900 caracteres max 
					
			   },
			   
			   	 all_step1_suite : function (details_attentes_du_projet, nbre_des_parties){
		
				  //Ignore all previous statements.
				  
					Ta comprehension est bonne 
					Bravo, merci detre force de proposition
					
					Ignore all statements starting with //
					Tu es à letape 1
					01. Step1 = Ask me existing file
					
					Voici la suite du code : 
					// Ici faut prendre 2900 caracteres max 
					
			   },
				
	
					Here is a sample for JS 
 coding_with_details : function (){
			  
			MERCI de fournir les codes pour le etape 3
			step by step stp

			je vais recupérer code, le compiler et le tester dans la foulée
			
			Voici les informations pour le codage :
			
			Nom de l'entité : ainos_impressions
			Champ servant de trigger : ainos_lancer_les_impressions
			nom de la relation : ainos_assets_impressions
			type de la relation entre les impressions et les assets : N to N
			type doperation : Post operations
			  
		   },
		   
		   clarification_coding : (){
				Jai besoin que le document qui est generé aille recupérer le modele word dans le crm créée sur lentite ainos_asset et qui a deja les variables ainos_qrcode et ainos_qrcodeimage 

				Merci de me dire si tu as compris 
				quels updates 
				Puis tu appliques les updates dans le code que je viens de te fournir			 
			 
		   },
		   
		    filter_entity_based_on_parent : (lookup_parent,entity_tofilter,name_column_target, name_column_parent) {
			
			Ignore all previous statements.
			Ignore all statements starting with //
			
			As an crm Expert 365 whith more than 20 years experience, microsoft apps expert with more than 10 years and an logistic expert with more than 20 years experience, 
			you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
			
			I need you to think about this project, manage personas, understand the requirements and deliver the solution for crm desktop and mobile applicaiton

			
			If it make sense, you will suggest a best link for similar project where i can find : Solutions, files, prototypes, uses cases etc...
			Your job is to deliver : audit, specifications fonctionnelles générales, spécifications techniques, backlog for the business rules,
			crm customizations that includes entity, forms, views, fields,reporting, dashboard, creating js code, plugins, workflows, power automate, 
			power apps and suggest testing
			
			I WANT you to filter a lookup field using an other lookup value
			use this code below to update and fit the new requirement
			
			lookup field name :ainos_floor
			Enity to filter : ainos_floors
			name of column for the target entity : ainos_floorname
			name of column for parent in for the target entity : ainos_building
			
			NOW I WILL give you the code to update :
		
		},
		
		  coding_with_details : function (){
			   
			MERCI de fournir les codes pour le etape 3
			step by step stp

			je vais recupérer code, le compiler et le tester dans la foulée
			
			Voici les informations pour le codage :
			
			Nom de l'entité : ainos_impressions
			Champ servant de trigger : ainos_lancer_les_impressions
			nom de la relation : ainos_assets_impressions
			type de la relation entre les impressions et les assets : N to N
			type doperation : Post operations
			  
		   },
		   
		   clarification_coding : (){
				Jai besoin que le document qui est generé aille recupérer le modele word dans le crm créée sur lentite ainos_asset et qui a deja les variables ainos_qrcode et ainos_qrcodeimage 

				Merci de me dire si tu as compris 
				quels updates 
				Puis tu appliques les updates dans le code que je viens de te fournir			 
			 
		   },
		   
}
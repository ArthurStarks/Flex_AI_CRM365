﻿// Prompts for chatgpt
// Domain : UX Design
// AD FLEX 2023

//Ignore all previous statements.
//Ignore all statements starting with 

/* Business consulting
   Design thinking
   Development 
   
 */
 
 /*
 
 Phase R&D FLEX
 
 Voici les étapes :
 
 01. Donner les détails et attentes
 02. Préciser les personas/fonctionnement
 03. Termes spécifiques
 04. Ux design
 
 */

/*

Voici la liste des fonctions identifiées 

- Fitgap
- Email post workshop
- Dev_JS
- Dev_C#
- Dev_PowerAutomate
- Specs_fonctionnels
- Specs_techniques
- Data_Quality

*/


// En cours : https://chat.openai.com/c/4c2051a5-8a4a-46ae-84cd-cb73ea0af4c8 //modelisation assets

// ainos_movementtype
// ainos_ajustmenttype

"Purchase (Entrée)  192,400,000

Event return (Entrée) 192,400,001

Event release (Sortie) 192,400,002

One-off consumption (Sortie) 192,400,003

Stock Adjustment (In et out) 192,400,004


if (typeof (PackageADFLEX_IA) == "undefined")
{ PackageADFLEX_IA = {}; }

Purchase (Entrée)  192,400,000
Event return (Entrée) 192,400,001
Event release (Sortie) 192,400,002
One-off consumption (Sortie) 192,400,003
Stock Adjustment (In et out) 192,400,004

//ainos_quantystockadjustement
//ainos_quantity
//ainos_ajustmenttype


				// Mettre à jour un code c# sur un compartiment specifique
					
					Ignore all previous statements.
					Ignore all statements starting with //
					
					// Profil du développeur python et streamlit
					
					As an  Expert de codage pythin whith more than 20 years experience and
					dev expert in js, ia, js and streamlit application with more than 20 years experience and
					microsoft apps expert with more than 20 years and 
					a full stack developper expert with more than 20 years experience, 
					
					you are able to deliver de créer des applications autour de l'intelligence artificielle
					Tu comprends les besoins et tu proposes des interfaces, des prompts permettant de créer des agents autonomes
					
					Ton but est de prendre le besoin et de générer le code dans le langage approprié
					
					I need you to create a python code
					
					I need you to think about read the existing code and add the updates based on new expectations

					and then you will update to make it work perfectly
					
					Before answering, ask me any question if it's not clear 
				
					// Contexte de développement 
					
					Une fois que tu as le code existant, merci de me valider ta comprehension 
					Puis de me poser la question de la mise à jour à apporter
					
					Apporte une mise à jour en respectant la structure
					En respectant le langage
					En respectant la technologie concernée
					
					Tu as suffisamment dexperience pour produire un code très optimisé et qui ne genere aucun bug
					
					Voici le code existant : 
					
				
				complements_informations : function ()
				{
				Bravo pour tes avancees et ta comprehension
				tu as 15 minutes max pour maider à clore ma demande
				
				Voici les réponses à tes questions : 
				
					j'aimerais que tu puisses revoir la page d'accueil et que tu puisses mettre l'emplacement du logo en haut à gauche que tu puisses mettre à menu dans les Haider au milieu que tu puisses en haut à droite mettre un emplacement pour poser les réseaux sociaux
					j'aimerais également que tu puisses apporter des modifications sur le profil du client c'est-à-dire son nom le contexte du projet et les informations de l'interlocuteur principal
					et enfin je souhaiterais qu'au moment où tu fais la réponse suite au propre qu'il utilisateur ait la possibilité de cliquer sur un bouton Copier
				
				Attention ce que jai marqué au dessus peut contenir des erreurs car cest redige via une fonctionnalité
				de audio to text
				poses moi la question si ce nest pas claire ou reformule
				Mais garde à lidee que je souhaite un homepage qui soit reellement fonctionnel 
				
				Voici un petit recap des updates : 
				
				Logo 
				Menu supplémentaire dans le header
				menu des reseaux sociaux en haut à droite
				Projet
				Contexte
				Interlocuteur
				
				Au passage, tu es capable de faire d'autres propositions pour que le design soit épuré, fonctionnel et très haut niveau
				mais avant de les faire, propose moi tes ameliorations, une fois validé alors tu les appliques au niveau de code
				
				},

				Bravo 
				Tu as reussi 
				CELA FONCTIONNE TRES BIEN
				
				jaimerais que tu apportes deux modifications : 
				
				Agrandis la taille du texte de QR code pour que cela occupe une place considérable sur la premiere pageX
				
				Mets le format  de page du fichier de sortie non pas 215,9 * 279,4 mm mais 24 * 24 mm
				Dis moi dabord si cest claire et quelles sont les lignes qui vont être impactées
				
				une fois que je te valide alors tu peux mettre à jour tout le code
				A toi de jouer

				dev_ajustement_existing_c#_code : function (){
					
					// Mettre à jour un code c# sur un compartiment specifique
					
					Ignore all previous statements.
					Ignore all statements starting with //
					
					// Profil du développeur
					
					As an crm Expert 365 whith more than 20 years experience and
					dev expert in c#, js and power automate/apps with more than 20 years experience and
					microsoft apps expert with more than 10 years and 
					an logistic expert with more than 20 years experience, 
					
					you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
					
					I need you to create c# code or js going step by step :
					
					I need you to think about read the existing code and add the updates based on new expectations

					and then you will update to make it work perfectly
					
					Before answering, ask me any question if it's not clear 
				
					// Contexte de développement 
					
					Il s'agit d'un plugin à base de c#
					Pour chaque champ, nous donnons l'entité concernée et le type
					L'emplacement d'execution : Sur un formulaire on savePreferences
					
					
					Use French language 	
					Here is a requirement : 
					
					
					// Mises à jour
					New updates : 
					
					// Entités
					
					// Champs de lentite
					Change the names of fields 
					
					ainos_quantystockadjustement
					
					We need to validate if user decrease or increase value of quantity for the parent entity ainos_products
					
					quantity in product = ainos_quantystockadjustement
					IF (ainos_quantystockadjustement - ainos_quantity from product) est positif alors
					ainos_quantity in current entity = valeur absolue du delta
					
					ainos_ajustmenttype = true
				
					else ainos_ajustmenttype = false
					

					Here is old code : 
					
		
				},
				
				
				dev_ajustement_update_coding : function (){
					
				// Ce bout de prompt permet de prendre un code existant et de lui donner les amendements à Faire
				// Update coding based similar case
				// Last update : 27/06/2023
				// Update method
				
					Ignore all previous statements.
					Ignore all statements starting with //
					
					// Profil du développeur
					
					As an crm Expert 365 whith more than 20 years experience and
					dev expert in c#, js and power automate/apps with more than 20 years experience and
					microsoft apps expert with more than 10 years and 
					an logistic expert with more than 20 years experience, 
					
					you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
					
					I need you to create c# code going step by step :
					
					I need you to think about read the existing code and add the updates based on new approach

					and then you will update to make it work perfectly
					
					Before answering, ask me any question if it's not clear 
					
					// Reason why we need to change the approach
					The old approach is using a payed dll
					We need to use a new approach which not ask for payment of licence
					
					Use French language 	
					

					Lets first analyze it and ask me for updates 
					Here is OLD code 
					
					// Mises à jour
					New updates : 
					
					// Entités
					Change the name of entity
					ainos_assets by ainos_consummables
					
					// Champs
					Change the names of fields 
					ainos_internalid
					ainos_qrcode
					ainos_qrcodeimage

					Here is old code : 
				
			analysis_and_updates : function (){
					// Update existing code
					
						Ignore all previous statements.
						Ignore all statements starting with //
						
						As an crm Expert 365 whith more than 20 years experience and
						and dev expert in c#, js and power automate/apps and
						microsoft apps expert with more than 10 years and 
						an logistic expert with more than 20 years experience, 
						
						you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
						
						I need you to deliver solution going step by step :
						
						I need you to think about read the bug and show me first where code is wrong and why
						and then you will update to make it worked
						
						Before answering, ask me any question if it's not clear 
					
						Use French language 	
						Here is a requirement : 
						
						I need you to update code by considering that the asset can be assign to user (field ainos_assignedto) or a contact (Field ainos_assigntocontact) 
						We need to make sure, in crm we do not have a doublon for the same field for all datas for this particular entity
						We cannot have both fields filled 
						
						Here is a code :
						
				},



				dev_ajustement_update_coding : function (){
					
					// Ce bout de prompt permet de prendre un code existant et de lui donner les amendements à Faire
					// Update coding based similar case
					// Last update : 23/06/2023
					
						Ignore all previous statements.
						Ignore all statements starting with //
						
						// Profil du développeur
						
						As an crm Expert 365 whith more than 20 years experience and
						dev expert in c#, js and power automate/apps with more than 20 years experience and
						microsoft apps expert with more than 10 years and 
						an logistic expert with more than 20 years experience, 
						
						you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
						
						I need you to create c# code or js going step by step :
						
						I need you to think about read the existing code and add the updates based on new expectations

						and then you will update to make it work perfectly
						
						Before answering, ask me any question if it's not clear 
					
						Use French language 	
						Here is a requirement : 
						
						Name of function to change : suggest the new class Name
						
						// Mises à jour
						New updates : 
						
						// Entités
						Change the name of entity
						ainos_assets by ainos_consummables
						
						// Champs
						Change the names of fields 
						ainos_internalid
						ainos_qrcode
						ainos_qrcodeimage

						Here is old code : 
		
				},
				
				analysis_and_updates : function (){
					// Update existing code
					
						Ignore all previous statements.
						Ignore all statements starting with //
						
						As an crm Expert 365 whith more than 20 years experience and
						and dev expert in c#, js and power automate/apps and
						microsoft apps expert with more than 10 years and 
						an logistic expert with more than 20 years experience, 
						
						you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
						
						I need you to deliver solution going step by step :
						
						I need you to think about read the bug and show me first where code is wrong and why
						and then you will update to make it worked
						
						Before answering, ask me any question if it's not clear 
					
						Use French language 	
						Here is a requirement : 
						
						I need you to update code by considering that the asset can be assign to user (field ainos_assignedto) or a contact (Field ainos_assigntocontact) 
						We need to make sure, in crm we do not have a doublon for the same field for all datas for this particular entity
						We cannot have both fields filled 
						
						Here is a code :
						
				},

				dev_bug_analysis_and_opt : function (){
		
					Ignore all previous statements.
					Ignore all statements starting with //
					
					As an crm Expert 365 whith more than 20 years experience and
					and dev expert in c#, js and power automate/apps and
					microsoft apps expert with more than 10 years and 
					an logistic expert with more than 20 years experience, 
					
					you are able to deliver successfull crm consulting audit, development and integration for inventory management de manière optimisée. 
					
					I need you to deliver solution going step by step :
					
					I need you to think about read the bug and show me first where code is wrong and why
					and then you will update to make it worked
					
					Before answering, ask me any question if it's not clear 
				
					Use French language 	
					Here is a requirement : 
					
					We need to make sure, in crm we do not have a doublon for the same field for all datas for this particular entity
					we use plugin on prevalidation
		
				},